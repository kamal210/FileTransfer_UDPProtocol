/*
//========================================================
//UDP FILE TRANSFER SERVER(receive)
//========================================================
//Developed by: Kamal Panthi 
//Email: kamal210@hotmail.com
//        
//To Compile type make 
//To run the server type: "./receive portnumber"
//======================================================== 

Acknowledgement:

http://www.csharphelp.com/archives2/archive335.html
http://www.tcnj.edu/~bush/uftp.html
http://www.linuxquestions.org/questions/programming-9/best-way-to-transfer-files-in-linux-thru-c-programming-657577/
http://www.dreamincode.net/forums/showtopic27741.htm
http://www.allegro.cc/forums/thread/580811/1

Stevens, W.R.: Unix Network Programming, The Sockets Networking API, Vol. 1, 3rd Ed., Prentice Hall, 2004.
Internetworking with TCP/IP Vol. 3: Client-Server Programming and Application, Linux/POSIX Socket Version (Comer, D.E., Stevens, D.), 2000. 


//======================================================== */

//==================Header Declarations===================
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>

//===================#Defines=============================
#define NOWORK 0 
#define REQUEST 1
#define DATA 2
#define ACK 3
#define ERR 4
#define COMPLETE 5 




//================Global Variable Declaration=============
bool connectedclient=false, connected=false;


                    


//=======================Error display Function=============
void err(char *msg)
{
    perror(msg);
    exit(0);
}

 		
                     



//=====================MAIN=================================
int main(int argc, char *argv[])
{
	fd_set fd_readfd,fd_testfd;//file descripter set for select
	int fd_socket,s,c, length, fromlen, n;//INTEGER VARIABLES
	struct sockaddr_in ser_sock, cli_sock;//sockaddress for server and client
	char buffer[512], recvbuffer[512], message[51200], FILENAME[512],file_read_bfr[100000];//string buffer 
	
	double time;	
	struct timeval timerout, begin,end;
	timerout.tv_sec = 120000;//initializaztion of timer
	timerout.tv_usec = 500000;
	unsigned short int blockno=0,opcodebyte=0,datapacketnumber,errno=0;
	unsigned int lenpack;
	int sentblockno=0;
	int fd,file_create,file_write,file_open;
	int flags;
    	mode_t mode;
	int totalpacketsreceived=0,totalpacketswritten=0,totalacknowledgement=0,size=0, acksamepack=0;
	
	//========checking for valid run parameters======
   	if (argc < 2) 
	{
		printf("Usage: ./receive portnumber\n");
      		fprintf(stderr, "please provide the port\n");
      		exit(0);
   	}

	//========creating socket for communication======
   	fd_socket=socket(AF_INET, SOCK_DGRAM, 0);
   	if (fd_socket < 0) 
		err("socket open error");

   	length = sizeof(ser_sock);
   	bzero(&ser_sock,length);
   	ser_sock.sin_family=AF_INET;
   	ser_sock.sin_addr.s_addr=htonl(INADDR_ANY);
   	ser_sock.sin_port=htons(atoi(argv[1]));

	//========Binding socket ============================
	if (bind(fd_socket,(struct sockaddr *)&ser_sock,length)<0) 
		err("bind");

	fromlen = sizeof(struct sockaddr_in);
	bzero(message,51200);
	//fill the select macros
	FD_ZERO(&fd_readfd);
	FD_SET(fd_socket,&fd_readfd);
	FD_SET(0,&fd_readfd);
	//=================Head Display For client==================
	printf("\n ========================================");
   	printf("\n          UDP FILE TRANSFER SERVER");	
	printf("\n ========================================");
	printf("\n Developed by: Kamal Panthi ");
	printf("\n Student ID: c0346747");
	printf("\n Email: kamal.panth@lut.fi");
	printf("\n This program can transfer any type of file and any size of file.");
	printf("\n ========================================\n");
	//while loop
   	while (1) 
	{

		//set the select command
		fd_testfd=fd_readfd;
		s=select(FD_SETSIZE,&fd_testfd,0,0,&timerout);	
		if(s<0)
		{
			perror("error in select\n");
			exit(1);
		}
		else if(s==0)
		{
			if(connectedclient==true)
			{
				//if(exceeds 10) then give the message for abnormal transfer  
				if(acksamepack>=10)
				{
					printf("The ACK for packet number: %d was sent for 10 times or more",acksamepack); 
					printf("still no successful cooperation with client achieved.\n");
					printf("So, The connection with client is being terminated abnornally!!\n");
					printf("The transfer statistics for the so far received data and written is below.\n");
					sprintf(message,"%sThe ACK for Packet No: %d was sent %d times.\n", message, totalpacketswritten+1, acksamepack + 1);
					//display the statistics
					//==========Mark end time for file transfer
					gettimeofday(&end,NULL);

					struct stat stbuf;
					stat(FILENAME, &stbuf);
					size = stbuf.st_size;
					

					printf("=======================================================\n\n");
					printf("%s\n",message);
					//display total retransmission

					printf("Total number of packets received = %d\n",totalpacketsreceived);
					printf("Total packets written to file = %d\n",totalpacketswritten);
					printf("Total Acknowledgement Sent = %d\n",totalacknowledgement);
					printf("Total packet loss or delayed = %d\n",totalacknowledgement-totalpacketswritten-1);
					printf("Total packet loss or delayed percentage = %lf(o/o)\n\n",(((double)totalacknowledgement-(double)totalpacketswritten-1)*100)/(double)totalpacketswritten);
					//print total file transfer time and transfer rate per packet and per mb
					//========Calculate the total file transfer time(in secs)==================== 
					time = end.tv_sec - begin.tv_sec + ( end.tv_usec - begin.tv_usec ) / 1.e6f;
			
					//=======Printing the transfer speed=========================================
					printf("%d bytes received in %lf secs   (%lf Kb/sec) \n",size, time,(double)size/(time*1024));
					printf("=======================================================\n");
					connectedclient=false;
					printf("Connection was terminated forcefully with client!!\n");
					printf("So far received data is written in the file %s!!\n",FILENAME);
					timerout.tv_sec = 120000;//initializaztion of timer
					timerout.tv_usec = 500000;
					
				}
				else
				{
					//send the same packet
					n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);	
					if (n < 0) 
						err("Sendto");

					acksamepack++;
					totalacknowledgement++;
					//resetting the timer
					timerout.tv_sec = 10;
					timerout.tv_usec = 500000;
					
				}
			}
			else
			{
				timerout.tv_sec = 120000;//reinitializaztion of timer
				timerout.tv_usec = 500000;
			}
		}
		else
		{
			if(FD_ISSET(fd_socket,&fd_testfd))//check if input came from socket
			{
				bzero(recvbuffer,512); 
				//receive buffer from socket
	    			n = recvfrom(fd_socket,recvbuffer,sizeof(recvbuffer),0,(struct sockaddr *)&cli_sock, &fromlen);
				recvbuffer[n]=0;
				if (n < 0) 
					err("recvfrom");
				
				//Reading the Opcode
				memcpy(&opcodebyte,recvbuffer,2);
				opcodebyte=ntohs(opcodebyte);

				if(opcodebyte==REQUEST)
				{

					if(connectedclient==true)
					{
						
						//send the Error message to client that already some client is connected
						memset(buffer,0,512); 	
						opcodebyte=htons(ERR);//setting the upcode for error	
						//Packaging the ERROR buffer
						memcpy(buffer,&opcodebyte,2);
						errno=htons(1);//setting the upcode for error number for client busy	
						memcpy(&buffer[2],&errno,2);
						lenpack=2+2;	
						n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);
						
						if (n < 0) 
							err("Sendto");
						printf("New Client is trying to connected but permission denied.\n");
					}
					else
					{
						memset(FILENAME,0,512); 
						//memcpy(buffer,&opcodebyte,2);
						sprintf(FILENAME,"%s",&recvbuffer[2]);	
						flags=O_RDONLY; // read only
		
						//================Check whether file exists or not======================
						fd=open(FILENAME, flags, mode);
						if(fd<0)//if error
						{
							connected=true;
						}
						else
						{
							//send the Error message to client that file already exist
							memset(buffer,0,512); 	
							opcodebyte=htons(ERR);//setting the upcode for error	
							//Packaging the ERROR buffer
							memcpy(buffer,&opcodebyte,2);
							errno=htons(2);//setting the upcode for error number for file exist	
							memcpy(&buffer[2],&errno,2);
							lenpack=2+2;	
							n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);			
							if (n < 0) 
								err("Sendto");
							connected=false;
							printf("Client is trying to upload the File with name: %s which already exists so permission denied.\n",FILENAME);
						
						}
						close(fd);
						if(connected==true)
						{
							
							//Create the file in the client for the download
							file_create=creat(FILENAME,S_IRWXU);
							//send the ACK to client to start data transfer
							memset(buffer,0,512); 	
							opcodebyte=htons(ACK);//setting the upcode for ACK	
							//Packaging the ACK buffer
							memcpy(buffer,&opcodebyte,2);
							sentblockno=0;
							totalpacketsreceived=0;
							totalpacketswritten=0;
							totalacknowledgement=0;
							size=0;
							blockno=htons(sentblockno);//setting the blockno for start file transfer	
							memcpy(&buffer[2],&blockno,2);	
							lenpack=2+2;
							n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);			
							if (n < 0) 
								err("Sendto");
							acksamepack=0;
							totalacknowledgement++;
							sentblockno++;
							connectedclient=true;
							connected=false;
							//resetting the timer
							timerout.tv_sec = 10;
							timerout.tv_usec = 500000;
						}
					}

				}
				else if(opcodebyte==DATA)
				{
					totalpacketsreceived++;
					//Reading the blockno
					memcpy(&blockno,&recvbuffer[2],2);
					blockno=ntohs(blockno);
					if(blockno==sentblockno)
					{
						if(blockno==1)							
							gettimeofday(&begin,NULL);//Start the timer to calculate the transfer speed
						if(acksamepack>0)//ACK for previous packet is more than 1
						{
							sprintf(message,"%sThe ACK for Packet No: %d was sent %d times.\n", message, totalpacketswritten+1, acksamepack + 1);
						}
						//write to file
						file_write=write(file_create,&recvbuffer[4],n-4);//Write to file 
						totalpacketswritten++;
						//send the ACK to client for next packet
						memset(buffer,0,512); 	
						opcodebyte=htons(ACK);//setting the upcode for ACK	
						//Packaging the ACK buffer
						memcpy(buffer,&opcodebyte,2);						
						blockno=htons(blockno);//setting the blockno for next packet	
						memcpy(&buffer[2],&blockno,2);
						lenpack=2+2;	
						n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);			
						if (n < 0) 
							err("Sendto");
						acksamepack=0;
						totalacknowledgement++;
						sentblockno++;
						
						//resetting the timer
						timerout.tv_sec = 10;
						timerout.tv_usec = 500000;
						
					}
					else
					{
						//if(exceeds 10) then give the message for abnormal transfer  
						if(acksamepack>=10)
						{
							printf("The ACK for packet number: %d was sent for 10 times or more",acksamepack); 
							printf("still no successful cooperation with client achieved.\n");
							printf("So, The connection with client is being terminated abnornally!!\n");
							printf("The transfer statistics for the so far received data and written is below.\n");
							sprintf(message,"%sThe ACK for Packet No: %d was sent %d times.\n", message, totalpacketswritten+1, acksamepack + 1);
							//display the statistics
							//==========Mark end time for file transfer
							gettimeofday(&end,NULL);

							struct stat stbuf;
							stat(FILENAME, &stbuf);
							size = stbuf.st_size;

							printf("=======================================================\n\n");
							printf("%s\n",message);
							//display total retransmission

							printf("Total number of packets received = %d\n",totalpacketsreceived);
							printf("Total packets written to file = %d\n",totalpacketswritten);
							printf("Total Acknowledgement Sent = %d\n",totalacknowledgement);
							printf("Total packet loss or delayed = %d\n",totalacknowledgement-totalpacketswritten-1);
							printf("Total packet loss or delayed percentage = %lf(o/o)\n\n",(((double)totalacknowledgement-(double)totalpacketswritten-1)*100)/(double)totalpacketswritten);
							//print total file transfer time and transfer rate per packet and per mb
							//========Calculate the total file transfer time(in secs)==================== 
							time = end.tv_sec - begin.tv_sec + ( end.tv_usec - begin.tv_usec ) / 1.e6f;
					
							//=======Printing the transfer speed=========================================
							printf("%d bytes received in %lf secs   (%lf Kb/sec) \n",size, time,(double)size/(time*1024));
							printf("=======================================================\n");
							connectedclient=false;
							printf("Connection was terminated forcefully with client!!\n");
							printf("So far received data is written in the file %s!!\n",FILENAME);
							timerout.tv_sec = 120000;//initializaztion of timer
							timerout.tv_usec = 500000;
							
						}
						else
						{
							//send the same packet
							n=sendto(fd_socket,buffer,lenpack,0,(struct sockaddr *)&cli_sock,fromlen);	
							if (n < 0) 
								err("Sendto");

							acksamepack++;
							totalacknowledgement++;
							//resetting the timer
							timerout.tv_sec = 10;
							timerout.tv_usec = 500000;
							
						}
					}
				}
				else if(opcodebyte==COMPLETE)
				{
					//display the statistics
					//==========Mark end time for file transfer
					gettimeofday(&end,NULL);

					struct stat stbuf;
					stat(FILENAME, &stbuf);
					size = stbuf.st_size;


					printf("=======================================================\n\n");
					printf("%s\n",message);
					//display total retransmission

					printf("Total number of packets received = %d\n",totalpacketsreceived);
					printf("Total packets written to file = %d\n",totalpacketswritten);
					printf("Total Acknowledgement Sent = %d\n",totalacknowledgement);
					printf("Total packet loss or delayed = %d\n",totalacknowledgement-totalpacketswritten-1);
					printf("Total packet loss or delayed percentage = %lf (o/o)\n\n",(((double)totalacknowledgement-(double)totalpacketswritten-1)*100)/(double)totalpacketswritten);
					//print total file transfer time and transfer rate per packet and per mb
					//========Calculate the total file transfer time(in secs)==================== 
					time = end.tv_sec - begin.tv_sec + ( end.tv_usec - begin.tv_usec ) / 1.e6f;
					
					//=======Printing the transfer speed=========================================
					printf("%d bytes received in %lf secs   (%lf Kb/sec) \n",size, time,(double)size/(time*1024));
					printf("=======================================================\n");
					connectedclient=false;
					printf("File received successfully!!\n");
					timerout.tv_sec = 120000;//initializaztion of timer
					timerout.tv_usec = 500000;
				}
				else
				{
					
					
				}

			}
		}



		
	}
	
}



